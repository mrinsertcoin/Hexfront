extends "res://tests/hotseat.gd"

func _next_round() -> void:
	click(board.end_turn_button.get_global_rect().get_center())
	click(board.end_turn_button.get_global_rect().get_center())

func _hover(hex: Vector2i) -> void:
	# Exercise the same hover projection/query as the per-frame mouse handler.
	board.update_hover_at(_screen(hex))

func _fixture() -> void:
	board.game_state.units.clear()
	board.game_state.units[1] = GameState.Unit.new(1, 1, "Gunner", Vector2i(4, 4))
	board.game_state.units[2] = GameState.Unit.new(2, 1, "Scout", Vector2i(4, 3))
	board.game_state.units[3] = GameState.Unit.new(3, 2, "Scout", Vector2i(6, 4))
	board.game_state.units[4] = GameState.Unit.new(4, 2, "Infantry", Vector2i(4, 5))
	board.game_state.units[4].hp = 1
	# This fixture replaces unit types as well as positions; recreate its
	# visual fixtures instead of reusing meshes for IDs from the live setup.
	for view: MeshInstance3D in board.unit_views.values():
		board.remove_child(view)
		view.queue_free()
	board.unit_views.clear()
	board.health_fills.clear()
	board.clear_selection()

func _check_fresh() -> void:
	var initial := GameState.new()
	check(board.game_state.units.size() == 6 and board.game_state.structures.size() == 2 and board.unit_views.size() == 8 and board.health_fills.size() == 8, "Restart restores six military units, two headquarters, and eight views/bars")
	for id: int in initial.units:
		var unit: GameState.Unit = board.game_state.units[id]
		var expected: GameState.Unit = initial.units[id]
		check(unit.hex == expected.hex and unit.hp == expected.max_hp and not unit.moved and not unit.attacked, "Restart restores position, HP, and actions")
		check(is_equal_approx(board.health_fills[id].scale.x, 1.0), "Restart fills health bars")
	check(board.game_state.winner_id == 0 and board.game_state.active_player == 1 and board.game_state.round_number == 1, "Restart restores active match")
	check(board.selected_unit_id == -1 and board.selected == board.NONE and board.preview_path.is_empty() and board.reachable_tiles.is_empty() and board.attack_tiles.is_empty(), "Restart clears all selection and highlights")
	check(board.hover_hex == board.NONE and board.attack_preview_label.text.is_empty() and board.feedback_label.text.is_empty(), "Restart clears hover and combat feedback")
	check(not board.end_turn_button.disabled and not board.restart_button.visible, "Restart restores UI controls")
	var center: Vector3 = HexGrid.to_world(Vector2i.ZERO).lerp(HexGrid.to_world(Vector2i(9, 9)), 0.5) + Vector3(0, sin(deg_to_rad(board.cam_default_pitch)), -cos(deg_to_rad(board.cam_default_pitch))) * board.cam_default_distance
	check(board.camera.position.is_equal_approx(center) and is_equal_approx(board.camera.size, board.cam_default_distance), "Restart resets camera")
	check(board.end_turn_button.pressed.get_connections().size() == 1 and board.restart_button.pressed.get_connections().size() == 1, "No duplicate button signal connections")

func _capture(name: String) -> void:
	if not OS.get_cmdline_user_args().has("--capture"):
		return
	await process_frame
	await RenderingServer.frame_post_draw
	var error: Error = root.get_texture().get_image().save_png("res://.godot/" + name + ".png")
	check(error == OK, "Save graphical capture")

func _shoot_standard_target(target_id: int) -> void:
	var target: RefCounted = board.game_state.units.get(target_id) if board.game_state.units.has(target_id) else board.game_state.structures.get(target_id)
	var shots: int = ceili(float(target.hp) / board.game_state.units[5].attack_damage)
	for shot in range(shots):
		click(_screen(board.game_state.units[5].hex))
		var target_hex: Vector2i = target.hex
		click(_screen(target_hex), MOUSE_BUTTON_RIGHT)
		check(board.game_state.units[5].attacked, "Standard battle attack routed through input")
		if board.game_state.winner_id == 0:
			_next_round()
	check(not board.game_state.units.has(target_id) and not board.game_state.structures.has(target_id), "Standard battle target eliminated")

func _run() -> void:
	root.size = Vector2i(1152, 648)
	board = Main.instantiate() as HexBoard
	# Instant presentation keeps this rules/input regression suite synchronous.
	board.animate_movement = false
	root.add_child(board)
	board._new_match("Hotseat")
	# Isolate scripted checks from physical keyboard pan during graphical runs.
	# Hover is exercised explicitly; desktop camera input remains a manual check.
	board.set_process(false)
	await process_frame
	await process_frame
	_check_fresh()
	var baseline_children: int = board.get_child_count()
	check(board.unit_views[5].get_node("visual_root/ModelRoot").get_child_count() == 1, "Gunner has exactly one model")
	await _capture("milestone3_initial")
	click(_screen(Vector2i(1, 1)))
	_hover(Vector2i(8, 8))
	check(board.attack_preview_label.text.is_empty(), "No actionable preview outside range")
	click(_screen(Vector2i(8, 8)), MOUSE_BUTTON_RIGHT)
	check(board.selected_unit_id == 1 and not board.game_state.units[1].attacked and board.feedback_label.text.contains("out of range"), "Invalid attack preserves selection and actions")

	_fixture()
	await process_frame
	var bar_position: Vector3 = board.health_fills[1].global_position
	click(board.camera.unproject_position(bar_position))
	check(board.selected_unit_id == 1, "Health bar does not obstruct tile picking")
	_hover(Vector2i(6, 4))
	check(board.attack_tiles.has(Vector2i(6, 4)) and board.tiles[Vector2i(6, 4)].material_override == board.attack_material, "Enemy gets distinct attack highlight")
	check(board.attack_preview_label.text.contains("HP 6 -> 3") and board.attack_preview_label.text.contains("survives"), "Enemy hover shows damage and remaining HP")
	check(board.unit_label.text.contains("HP:") and board.unit_label.text.contains("Attack: Ready"), "Selected combat stats and actions")
	click(_screen(Vector2i(6, 4)))
	_hover(Vector2i(4, 4))
	check(board.attack_tiles.is_empty() and board.attack_preview_label.text.is_empty(), "Enemy inspection grants no actionable previews")
	click(_screen(Vector2i(4, 4)))
	click(_screen(Vector2i(6, 4)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.units[3].hp == 3 and is_equal_approx(board.health_fills[3].scale.x, 0.5), "Damage updates logical HP and health bar")
	check(board.game_state.units[1].attacked and board.reachable_tiles.is_empty() and board.attack_tiles.is_empty(), "Attack removes movement and attack highlights")
	check(board.feedback_label.text.contains("dealt 3 damage"), "Damage feedback")
	click(_screen(Vector2i(6, 4)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.units[3].hp == 3 and board.selected_unit_id == 1 and board.feedback_label.text.contains("already attacked"), "Second attack rejected without losing selection")
	_next_round()
	click(_screen(Vector2i(4, 4)))
	_hover(Vector2i(6, 4))
	check(board.attack_preview_label.text.contains("LETHAL"), "Lethal hover preview")
	await _capture("milestone3_combat")
	click(_screen(Vector2i(6, 4)), MOUSE_BUTTON_RIGHT)
	check(not board.game_state.units.has(3) and not board.unit_views.has(3) and not board.health_fills.has(3), "Death removes logical unit, mesh and health bar")
	check(board.game_state.winner_id == 0, "Remaining enemy keeps match active")
	check(board.hover_hex == board.NONE and board.attack_preview_label.text.is_empty() and board.preview_path.is_empty(), "Death clears stale hover/path/preview")
	click(_screen(Vector2i(4, 3)))
	click(_screen(Vector2i(6, 4)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.units[2].hex == Vector2i(6, 4), "Freed tile accepts a subsequent movement command")
	_next_round()
	click(_screen(Vector2i(4, 4)))
	click(_screen(Vector2i(4, 5)), MOUSE_BUTTON_RIGHT)
	# Under milestone 4, eliminating all military units does not end the match while an HQ remains
	check(board.game_state.winner_id == 0 and not board.end_turn_button.disabled and not board.restart_button.visible, "Final death does not declare winner while HQ remains")
	_next_round()
	board.game_state.structures[101].hex = Vector2i(5, 4)
	board.game_state.structures[101].hp = 1
	board._refresh_display()
	click(_screen(Vector2i(4, 4)))
	_hover(Vector2i(5, 4))
	check(board.attack_preview_label.text.contains("LETHAL"), "HQ lethal preview")
	click(_screen(Vector2i(5, 4)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.winner_id == 1 and board.end_turn_button.disabled and board.restart_button.visible, "Headquarters destruction wins through mouse routing")
	var round_before: int = board.game_state.round_number
	click(board.end_turn_button.get_global_rect().get_center())
	check(board.game_state.round_number == round_before, "Disabled turn button cannot advance")
	click(_screen(Vector2i(6, 4)))
	check(board.selected_unit_id == 2 and board.unit_label.text.contains("Disabled"), "Inspection remains available after victory")
	click(_screen(Vector2i(6, 5)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.units[2].hex == Vector2i(6, 4), "Right-click actions disabled after victory")
	await _capture("milestone3_victory")
	board.camera.position += Vector3(2, 0, 1)
	board.camera.size = 12.0
	click(board.restart_button.get_global_rect().get_center())
	await process_frame
	await process_frame
	_check_fresh()
	check(board.get_child_count() == baseline_children, "No duplicated scene nodes after restart")

	# Complete a standard six-unit battle through viewport clicks only.
	# Player 2 intentionally passes; this is a scripted acceptance test, not AI.
	var route: Array[Vector2i] = [Vector2i(3, 1), Vector2i(4, 1), Vector2i(5, 1), Vector2i(6, 1)]
	for r in range(2, 8):
		route.append(Vector2i(6, r))
	for destination: Vector2i in route:
		click(_screen(board.game_state.units[5].hex))
		click(_screen(destination), MOUSE_BUTTON_RIGHT)
		check(board.game_state.units[5].hex == destination, "Standard battle gunner advances legally")
		_next_round()
	_shoot_standard_target(4)
	_shoot_standard_target(6)
	click(_screen(board.game_state.units[5].hex))
	click(_screen(Vector2i(7, 7)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.units[5].hex == Vector2i(7, 7), "Advance into melee support position")
	_shoot_standard_target(3)
	# Army elimination alone must not win.
	check(board.game_state.winner_id == 0 and board.game_state.units.size() == 3, "Standard six-unit battle does not declare HQ-based victory")
	click(_screen(board.game_state.units[5].hex))
	click(_screen(Vector2i(8, 7)), MOUSE_BUTTON_RIGHT)
	_shoot_standard_target(101)
	check(board.game_state.winner_id == 1, "Standard match ends when headquarters is destroyed")
	await process_frame
	click(board.restart_button.get_global_rect().get_center())
	await process_frame
	_check_fresh()
	check(board.get_child_count() == baseline_children, "Repeated restart has no duplicates")
	_fixture()
	board.game_state.units[3].hp = 1
	click(_screen(board.game_state.units[3].hex))
	check(board.selected_unit_id == 3, "Inspect target before external rules command")
	check(board.rules.try_attack(1, 1, 3).killed, "Independent rules command kills inspected target")
	board._refresh_display()
	check(board.selected_unit_id == -1 and board.selected == board.NONE and board.hover_hex == board.NONE and board.attack_tiles.is_empty(), "Refresh clears a dead selection and stale targeting references")
	board.restart_match()
	await process_frame
	_check_fresh()
	print("Combat UI checks complete: previews, damage, death, standard full battle, repeated restart; failures=", failures)
	quit(0 if failures == 0 else 1)
