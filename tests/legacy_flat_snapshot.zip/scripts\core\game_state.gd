class_name GameState
extends RefCounted

# Logical state only. Scene nodes read this; Rules applies gameplay commands.
class Unit extends RefCounted:
	var id: int
	var owner_id: int
	var unit_type: String
	var hex: Vector2i
	var movement: int
	var moved: bool = false
	var max_hp: int
	var hp: int
	var attack_range: int
	var attack_damage: int
	var attacked: bool = false
	var ready_next_turn: bool = false

	func _init(unit_id: int, owner: int, kind: String, coordinate: Vector2i, allowance: int = -1) -> void:
		id = unit_id
		owner_id = owner
		unit_type = kind.capitalize()
		hex = coordinate
		var stats: Dictionary = UnitTypes.STATS[unit_type]
		movement = int(stats["movement"]) if allowance < 0 else allowance
		max_hp = int(stats["hp"])
		hp = max_hp
		attack_range = int(stats["range"])
		attack_damage = int(stats["damage"])

class Structure extends RefCounted:
	var id: int
	var owner_id: int
	var structure_type: String
	var hex: Vector2i
	var max_hp: int
	var hp: int
	var recruit_available: bool = true

	func _init(struct_id: int, owner: int, kind: String, coordinate: Vector2i, hp_value: int) -> void:
		id = struct_id
		owner_id = owner
		structure_type = kind
		hex = coordinate
		max_hp = hp_value
		hp = max_hp

var units: Dictionary[int, Unit] = {}
var structures: Dictionary[int, Structure] = {}
var next_id: int = 200
var last_started_turn: int = -1
var materials: Dictionary[int, int] = {1: 8, 2: 8}
var active_player: int = 1
var round_number: int = 1
var winner_id: int = 0

func _init() -> void:
	reset_match()

func reset_match() -> void:
	units.clear()
	structures.clear()
	# Start generated IDs well above scene-created IDs to avoid collisions
	next_id = 200
	materials = {1: 8, 2: 8}
	active_player = 1
	round_number = 1
	winner_id = 0
	last_started_turn = -1
	units[1] = Unit.new(1, 1, "Infantry", Vector2i(1, 1))
	units[2] = Unit.new(2, 1, "Scout", Vector2i(1, 2))
	units[3] = Unit.new(3, 2, "Infantry", Vector2i(8, 8))
	units[4] = Unit.new(4, 2, "Scout", Vector2i(8, 7))

	units[5] = Unit.new(5, 1, "Gunner", Vector2i(2, 1))
	units[6] = Unit.new(6, 2, "Gunner", Vector2i(7, 8))

	# Headquarters structures (stable low IDs)
	structures[100] = Structure.new(100, 1, "Headquarters", Vector2i(0, 1), 25)
	structures[101] = Structure.new(101, 2, "Headquarters", Vector2i(9, 8), 25)
	start_turn()

func unit_at(hex: Vector2i) -> Unit:
	for unit: Unit in units.values():
		if unit.hex == hex:
			return unit
	return null

func structure_at(hex: Vector2i) -> Structure:
	for s: Structure in structures.values():
		if s.hex == hex:
			return s
	return null

func entity_at(hex: Vector2i) -> RefCounted:
	var u := unit_at(hex)
	if u != null:
		return u
	var s := structure_at(hex)
	if s != null:
		return s
	return null

func allocate_id() -> int:
	while units.has(next_id) or structures.has(next_id):
		next_id += 1
	var id := next_id
	next_id += 1
	return id


func start_turn() -> void:
	# Idempotent: repeated initialization/presentation cannot grant income twice.
	var turn: int = (round_number - 1) * 2 + active_player
	if winner_id != 0 or last_started_turn == turn:
		return
	last_started_turn = turn
	materials[active_player] += 3
	for unit: Unit in units.values():
		if unit.owner_id == active_player:
			unit.moved = false
			unit.attacked = false
			unit.ready_next_turn = false
	for structure: Structure in structures.values():
		if structure.owner_id == active_player:
			structure.recruit_available = true
