class_name GameRules
extends RefCounted

const Grid = preload("res://scripts/core/hex_grid.gd")

class Result extends RefCounted:
	var success: bool
	var reason: String
	var path: Array[Vector2i] = []
	var damage: int = 0
	var target_hp: int = 0
	var killed: bool = false
	var winner_id: int = 0

	func _init(accepted: bool, message: String, route: Array[Vector2i] = []) -> void:
		success = accepted
		reason = message
		path = route

var state: GameState

func _init(game_state: GameState) -> void:
	state = game_state

func _actor_error(actor: int) -> String:
	if state.winner_id != 0:
		return "Match over. Player %d wins. Restart to play again." % state.winner_id
	if actor != 1 and actor != 2:
		return "Unknown player."
	if actor != state.active_player:
		return "It is Player %d's turn." % state.active_player
	return ""

func _move_error(actor: int, unit_id: int) -> String:
	var actor_error: String = _actor_error(actor)
	if not actor_error.is_empty():
		return actor_error
	if not state.units.has(unit_id):
		return "That unit does not exist."
	var unit: GameState.Unit = state.units[unit_id]
	if unit.hp <= 0:
		return "That unit is no longer alive."
	if unit.owner_id != actor:
		return "You can only move your own units."
	if unit.attacked:
		return "Cannot move after attacking this turn."
	if unit.moved:
		return "This unit has already moved this turn."
	return ""

# The same bounded BFS powers highlights, previews, and command validation.
# A parent is assigned only on first discovery; Grid.DIRECTIONS breaks ties.
func _parents(unit: GameState.Unit) -> Dictionary[Vector2i, Vector2i]:
	var parents: Dictionary[Vector2i, Vector2i] = {}
	var costs: Dictionary[Vector2i, int] = {}
	var queue: Array[Vector2i] = [unit.hex]
	parents[unit.hex] = unit.hex
	costs[unit.hex] = 0
	var cursor: int = 0
	while cursor < queue.size():
		var current: Vector2i = queue[cursor]
		cursor += 1
		if costs[current] >= unit.movement:
			continue
		for direction: Vector2i in Grid.DIRECTIONS:
			var neighbor: Vector2i = current + direction
			if not Grid.contains(neighbor) or parents.has(neighbor):
				continue
			# Block movement through any occupied tile (units or structures)
			if state.entity_at(neighbor) != null:
				continue
			parents[neighbor] = current
			costs[neighbor] = costs[current] + 1
			queue.append(neighbor)
	return parents

func reachable(actor: int, unit_id: int) -> Array[Vector2i]:
	var destinations: Array[Vector2i] = []
	if not _move_error(actor, unit_id).is_empty():
		return destinations
	var unit: GameState.Unit = state.units[unit_id]
	var parents: Dictionary[Vector2i, Vector2i] = _parents(unit)
	for hex: Vector2i in parents:
		if hex != unit.hex:
			destinations.append(hex)
	return destinations

func path_to(actor: int, unit_id: int, destination: Vector2i) -> Array[Vector2i]:
	var path: Array[Vector2i] = []
	if not _move_error(actor, unit_id).is_empty():
		return path
	var unit: GameState.Unit = state.units[unit_id]
	if destination == unit.hex or not Grid.contains(destination):
		return path
	var parents: Dictionary[Vector2i, Vector2i] = _parents(unit)
	if not parents.has(destination):
		return path
	var current: Vector2i = destination
	path.append(current)
	while current != unit.hex:
		current = parents[current]
		path.append(current)
	path.reverse()
	return path

func try_move(actor: int, unit_id: int, destination: Vector2i) -> Result:
	var error: String = _move_error(actor, unit_id)
	if not error.is_empty():
		return Result.new(false, error)
	var unit: GameState.Unit = state.units[unit_id]
	if not Grid.contains(destination):
		return Result.new(false, "Choose a tile on the board.")
	if destination == unit.hex:
		return Result.new(false, "The unit is already on that tile.")
	if state.entity_at(destination) != null:
		return Result.new(false, "That tile is occupied.")
	var path: Array[Vector2i] = path_to(actor, unit_id, destination)
	if path.is_empty():
		return Result.new(false, "No open path within this unit's movement allowance.")
	# All rejection paths above are read-only. Apply only after validation.
	unit.hex = destination
	unit.moved = true
	return Result.new(true, "Moved %d step(s). Movement action spent." % (path.size() - 1), path)

func try_end_turn(actor: int) -> Result:
	var error: String = _actor_error(actor)
	if not error.is_empty():
		return Result.new(false, error)
	if state.active_player == 1:
		state.active_player = 2
	else:
		state.active_player = 1
		state.round_number += 1
	# Run authoritative per-turn start effects for the incoming player
	_start_turn()
	return Result.new(true, "Player %d's turn." % state.active_player)

func _start_turn() -> void:
	state.start_turn()

func _attack_error(actor: int, attacker_id: int, target_id: int) -> String:
	var error: String = _actor_error(actor)
	if not error.is_empty():
		return error
	# Attacker must be a living military unit
	if not state.units.has(attacker_id) or state.units[attacker_id].hp <= 0:
		return "The attacker does not exist or is no longer alive."
	# Target may be a unit or a structure
	var target_is_unit: bool = state.units.has(target_id)
	var target_is_struct: bool = state.structures.has(target_id)
	if not target_is_unit and not target_is_struct:
		return "The target does not exist or is no longer alive."
	# Reject dead unit targets (hp <= 0)
	if target_is_unit and state.units[target_id].hp <= 0:
		return "The target does not exist or is no longer alive."
	# Reject destroyed structures (hp <= 0)
	if target_is_struct and state.structures[target_id].hp <= 0:
		return "The target does not exist or is no longer alive."
	var attacker: GameState.Unit = state.units[attacker_id]
	var target_unit: GameState.Unit = state.units[target_id] if target_is_unit else null
	var target_struct: GameState.Structure = state.structures[target_id] if target_is_struct else null
	if attacker.owner_id != actor:
		return "You can only attack with your own units."
	if attacker_id == target_id:
		return "A unit cannot attack itself."
	# Disallow attacking own targets (unit or structure)
	if (target_unit != null and target_unit.owner_id == actor) or (target_struct != null and target_struct.owner_id == actor):
		return "Choose an enemy target."
	if attacker.attacked:
		return "This unit has already attacked this turn."
	var distance: int = Grid.distance(attacker.hex, target_unit.hex) if target_unit != null else Grid.distance(attacker.hex, target_struct.hex)
	if distance > attacker.attack_range:
		return "Target is out of range (range %d)." % attacker.attack_range
	return ""

# Returns a fresh result; queries never mutate units, actions, or match state.
# Damage is the fixed attack value, even when clamping HP prevents overkill.
func preview_attack(actor: int, attacker_id: int, target_id: int) -> Result:
	var error: String = _attack_error(actor, attacker_id, target_id)
	if not error.is_empty():
		return Result.new(false, error)
	var attacker: GameState.Unit = state.units[attacker_id]
	var result: Result
	if state.units.has(target_id):
		var target_u: GameState.Unit = state.units[target_id]
		result = Result.new(true, "%s dealt %d damage to %s." % [attacker.unit_type, attacker.attack_damage, target_u.unit_type])
		result.damage = attacker.attack_damage
		result.target_hp = maxi(0, target_u.hp - result.damage)
		result.killed = result.target_hp == 0
		if result.killed:
			result.reason += " %s eliminated." % target_u.unit_type
	else:
		var target_s: GameState.Structure = state.structures[target_id]
		result = Result.new(true, "%s dealt %d damage to %s." % [attacker.unit_type, attacker.attack_damage, target_s.structure_type])
		result.damage = attacker.attack_damage
		result.target_hp = maxi(0, target_s.hp - result.damage)
		result.killed = result.target_hp == 0
		if result.killed:
			result.reason += " %s destroyed." % target_s.structure_type
			# Headquarters destruction immediately ends the match
			if target_s.structure_type == "Headquarters":
				result.winner_id = actor
				result.reason += " Player %d wins!" % actor
	return result

func attack_targets(actor: int, attacker_id: int) -> Array[int]:
	var targets: Array[int] = []
	# Consider both unit and structure targets
	for target_id: int in state.units:
		if preview_attack(actor, attacker_id, target_id).success:
			targets.append(target_id)
	for target_id: int in state.structures:
		if preview_attack(actor, attacker_id, target_id).success:
			targets.append(target_id)
	return targets

func try_attack(actor: int, attacker_id: int, target_id: int) -> Result:
	var result: Result = preview_attack(actor, attacker_id, target_id)
	if not result.success:
		return result
	var attacker: GameState.Unit = state.units[attacker_id]
	attacker.attacked = true
	attacker.moved = true
	# Apply damage to unit or structure
	if state.units.has(target_id):
		var t_u: GameState.Unit = state.units[target_id]
		t_u.hp = result.target_hp
		if result.killed:
			state.units.erase(target_id)
	else:
		var t_s: GameState.Structure = state.structures[target_id]
		t_s.hp = result.target_hp
		if result.killed:
			state.structures.erase(target_id)
	# Update winner if any
	state.winner_id = result.winner_id
	return result

func recruit_error(actor: int, headquarters_id: int, unit_type: String) -> String:
	var error: String = _actor_error(actor)
	if not error.is_empty():
		return error
	if not state.structures.has(headquarters_id):
		return "That headquarters does not exist."
	var headquarters: GameState.Structure = state.structures[headquarters_id]
	if headquarters.structure_type != "Headquarters" or headquarters.hp <= 0:
		return "Choose a living headquarters."
	if headquarters.owner_id != actor:
		return "You do not control that headquarters."
	if not headquarters.recruit_available:
		return "This headquarters has already recruited this turn."
	var kind: String = unit_type.capitalize()
	if not UnitTypes.STATS.has(kind) or not UnitTypes.COSTS.has(kind):
		return "Unknown unit type."
	if state.materials[actor] < int(UnitTypes.COSTS[kind]):
		return "Insufficient materials."
	return ""

func recruit_destinations(actor: int, headquarters_id: int, kind: String) -> Array[Vector2i]:
	var destinations: Array[Vector2i] = []
	if not recruit_error(actor, headquarters_id, kind).is_empty():
		return destinations
	var headquarters: GameState.Structure = state.structures[headquarters_id]
	for direction: Vector2i in Grid.DIRECTIONS:
		var hex: Vector2i = headquarters.hex + direction
		if Grid.contains(hex) and state.entity_at(hex) == null:
			destinations.append(hex)
	return destinations

func try_recruit(actor: int, headquarters_id: int, unit_type: String, destination: Vector2i) -> Result:
	var error: String = recruit_error(actor, headquarters_id, unit_type)
	if not error.is_empty():
		return Result.new(false, error)
	var headquarters: GameState.Structure = state.structures[headquarters_id]
	if not Grid.contains(destination):
		return Result.new(false, "Choose a tile on the board.")
	if Grid.distance(headquarters.hex, destination) != 1:
		return Result.new(false, "Destination must be adjacent to the headquarters.")
	if state.entity_at(destination) != null:
		return Result.new(false, "Destination is occupied.")
	var kind: String = unit_type.capitalize()
	var unit := GameState.Unit.new(state.allocate_id(), actor, kind, destination)
	unit.moved = true
	unit.attacked = true
	unit.ready_next_turn = true
	state.units[unit.id] = unit
	state.materials[actor] -= int(UnitTypes.COSTS[kind])
	headquarters.recruit_available = false
	return Result.new(true, "%s recruited. Ready next turn." % kind)

func restart_match() -> void:
	state.reset_match()
	# Ensure the active player's turn-start effects are applied once
	_start_turn()

