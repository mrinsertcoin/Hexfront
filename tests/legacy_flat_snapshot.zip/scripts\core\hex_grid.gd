class_name HexGrid
extends RefCounted

const WIDTH: int = 10
const HEIGHT: int = 10
const SQRT_3: float = 1.7320508075688772
const DIRECTIONS: Array[Vector2i] = [
	Vector2i(1, 0), Vector2i(1, -1), Vector2i(0, -1),
	Vector2i(-1, 0), Vector2i(-1, 1), Vector2i(0, 1),
]

static func contains(hex: Vector2i) -> bool:
	return hex.x >= 0 and hex.x < WIDTH and hex.y >= 0 and hex.y < HEIGHT

static func to_world(hex: Vector2i) -> Vector3:
	return Vector3(SQRT_3 * (float(hex.x) + float(hex.y) / 2.0), 0.0, 1.5 * hex.y)

static func from_world(world: Vector3) -> Vector2i:
	var q: float = world.x / SQRT_3 - world.z / 3.0
	var r: float = world.z * 2.0 / 3.0
	var s: float = -q - r
	var rounded_q: int = roundi(q)
	var rounded_r: int = roundi(r)
	var rounded_s: int = roundi(s)
	var q_error: float = absf(rounded_q - q)
	var r_error: float = absf(rounded_r - r)
	var s_error: float = absf(rounded_s - s)
	if q_error > r_error and q_error > s_error:
		rounded_q = -rounded_r - rounded_s
	elif r_error > s_error:
		rounded_r = -rounded_q - rounded_s
	return Vector2i(rounded_q, rounded_r)

static func distance(a: Vector2i, b: Vector2i) -> int:
	var delta: Vector2i = a - b
	return maxi(absi(delta.x), maxi(absi(delta.y), absi(delta.x + delta.y)))

