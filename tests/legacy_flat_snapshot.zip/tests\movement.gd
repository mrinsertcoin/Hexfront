extends SceneTree

const Grid = preload("res://scripts/core/hex_grid.gd")
const State = preload("res://scripts/core/game_state.gd")
const Rules = preload("res://scripts/core/rules.gd")

var failures: int = 0
var checks: int = 0

func _initialize() -> void:
	call_deferred("_run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(message)

func _snapshot(state: GameState) -> String:
	return preload("res://tests/test_state.gd").snapshot(state)

func _reject_move(state: State, rules: Rules, actor: int, unit_id: int, destination: Vector2i, context: String) -> void:
	var before: String = _snapshot(state)
	var result: Rules.Result = rules.try_move(actor, unit_id, destination)
	check(not result.success, context + ": rejected")
	check(not result.reason.is_empty(), context + ": readable reason")
	check(_snapshot(state) == before, context + ": all state unchanged")

func _reject_end_turn(state: State, rules: Rules, actor: int, context: String) -> void:
	var before: String = _snapshot(state)
	var result: Rules.Result = rules.try_end_turn(actor)
	check(not result.success, context + ": rejected")
	check(not result.reason.is_empty(), context + ": readable reason")
	check(_snapshot(state) == before, context + ": all state unchanged")

func _empty_state() -> State:
	var state: State = State.new()
	state.units.clear()
	return state

func _add_unit(state: State, unit_id: int, owner: int, hex: Vector2i, movement: int = 2) -> void:
	state.units[unit_id] = State.Unit.new(unit_id, owner, "infantry", hex, movement)

func _detour_state(movement: int) -> State:
	var state: State = _empty_state()
	_add_unit(state, 1, 1, Vector2i(1, 1), movement)
	_add_unit(state, 2, 2, Vector2i(2, 1))
	return state

func _trapped_state() -> State:
	var state: State = _empty_state()
	_add_unit(state, 1, 1, Vector2i.ZERO, 3)
	_add_unit(state, 2, 1, Vector2i(1, 0))
	_add_unit(state, 3, 2, Vector2i(0, 1))
	return state

func _check_path(state: State, unit_id: int, path: Array[Vector2i], start: Vector2i, destination: Vector2i, context: String) -> void:
	check(not path.is_empty(), context + ": path exists")
	if path.is_empty():
		return
	check(path[0] == start and path[-1] == destination, context + ": endpoints")
	check(path.size() - 1 <= state.units[unit_id].movement, context + ": within allowance")
	var visited: Array[Vector2i] = []
	for index in range(path.size()):
		var hex: Vector2i = path[index]
		check(Grid.contains(hex), context + ": stays on board")
		check(not visited.has(hex), context + ": no repeated tiles")
		visited.append(hex)
		var occupant: State.Unit = state.unit_at(hex)
		check(occupant == null or occupant.id == unit_id, context + ": no occupied passage")
		if index > 0:
			check(Grid.DIRECTIONS.has(hex - path[index - 1]), context + ": adjacent steps")

func _test_initial_state_and_move() -> void:
	var state: State = State.new()
	var rules: Rules = Rules.new(state)
	check(state.active_player == 1 and state.round_number == 1, "Player 1 starts round 1")
	check(state.units.size() == 6, "Exactly six starting units")
	var expected_hexes: Array[Vector2i] = [Vector2i(1, 1), Vector2i(1, 2), Vector2i(8, 8), Vector2i(8, 7), Vector2i(2, 1), Vector2i(7, 8)]
	var expected_owners: Array[int] = [1, 1, 2, 2, 1, 2]
	var expected_types: Array[String] = ["infantry", "scout", "infantry", "scout", "gunner", "gunner"]
	for index in range(6):
		var unit: State.Unit = state.units[index + 1]
		check(unit.id == index + 1, "Stable starting ID")
		check(unit.owner_id == expected_owners[index] and unit.unit_type.to_lower() == expected_types[index], "Starting owner and type")
		check(unit.hex == expected_hexes[index] and unit.movement == int(UnitTypes.STATS[unit.unit_type]["movement"]), "Starting coordinates and allowance")
		check(not unit.moved, "Starting unit is ready")
	# The added P1 gunner occupies the old test destination (2,1).
	# Use another adjacent empty tile; preserve the one-step action assertion.
	var before_query: String = _snapshot(state)
	var preview: Array[Vector2i] = rules.path_to(1, 1, Vector2i(1, 0))
	check(_snapshot(state) == before_query, "Path query is read only")
	_check_path(state, 1, preview, Vector2i(1, 1), Vector2i(1, 0), "Legal preview")
	var result: Rules.Result = rules.try_move(1, 1, Vector2i(1, 0))
	check(result.success, "Legal one-step move succeeds")
	check(state.units[1].hex == Vector2i(1, 0), "Legal move updates logical position")
	check(state.units[1].moved, "Shorter-than-allowance move consumes entire action")
	check(result.path == preview, "Applied move uses previewed path")
	check(state.unit_at(Vector2i(1, 1)) == null, "Source is empty after move")
	check(state.unit_at(Vector2i(1, 0)) == state.units[1], "Destination occupancy follows state")
	check(state.units[1].id == 1 and state.units[1].owner_id == 1 and state.units[1].movement == int(UnitTypes.STATS["Infantry"]["movement"]), "Move preserves identity, owner and allowance")
	check(state.units[2].hex == Vector2i(1, 2) and not state.units[2].moved, "Other unit remains ready in place")
	check(rules.reachable(1, 1).is_empty(), "Spent unit has no highlighted destinations")
	check(rules.path_to(1, 1, Vector2i(3, 1)).is_empty(), "Spent unit has no preview")
	_reject_move(state, rules, 1, 1, Vector2i(3, 1), "Second move in the same turn")

func _test_rejections() -> void:
	var state: State = State.new()
	var rules: Rules = Rules.new(state)
	_reject_move(state, rules, 2, 1, Vector2i(1, 0), "Wrong actor for friendly unit")
	_reject_move(state, rules, 1, 3, Vector2i(8, 9), "Active actor commanding enemy")
	_reject_move(state, rules, 2, 3, Vector2i(8, 9), "Enemy owner acting out of turn")
	for actor: int in [-1, 0, 3]:
		_reject_move(state, rules, actor, 1, Vector2i(1, 0), "Invalid player %d" % actor)
	for unit_id: int in [-1, 0, 999]:
		_reject_move(state, rules, 1, unit_id, Vector2i(1, 0), "Nonexistent unit %d" % unit_id)
		check(rules.reachable(1, unit_id).is_empty(), "Missing unit has no highlights")
		check(rules.path_to(1, unit_id, Vector2i(1, 0)).is_empty(), "Missing unit has no preview")
	for hex: Vector2i in [Vector2i(-1, 1), Vector2i(10, 1), Vector2i(1, -1), Vector2i(1, 10)]:
		_reject_move(state, rules, 1, 1, hex, "Off-board destination %s" % hex)
	_reject_move(state, rules, 1, 1, Vector2i(1, 1), "Current tile")
	_reject_move(state, rules, 1, 1, Vector2i(9, 9), "Beyond movement allowance")
	_reject_move(state, rules, 1, 1, Vector2i(1, 2), "Friendly occupied destination")
	state.units[3].hex = Vector2i(1, 0)
	_reject_move(state, rules, 1, 1, Vector2i(1, 0), "Enemy occupied destination")
	for actor: int in [-1, 0, 2, 3]:
		_reject_end_turn(state, rules, actor, "Invalid end-turn actor %d" % actor)

func _test_paths() -> void:
	var trapped: State = _trapped_state()
	var trapped_rules: Rules = Rules.new(trapped)
	check(trapped_rules.reachable(1, 1).is_empty(), "Both owners block all passages from corner")
	check(trapped_rules.path_to(1, 1, Vector2i(2, 0)).is_empty(), "Cannot cross friendly blocker")
	check(trapped_rules.path_to(1, 1, Vector2i(0, 2)).is_empty(), "Cannot cross enemy blocker")
	_reject_move(trapped, trapped_rules, 1, 1, Vector2i(2, 0), "Trapped despite destination within hex distance")
	_reject_move(trapped, trapped_rules, 1, 1, Vector2i(1, 0), "Friendly blocker cannot be entered")
	_reject_move(trapped, trapped_rules, 1, 1, Vector2i(0, 1), "Enemy blocker cannot be entered")
	var short_state: State = _detour_state(2)
	var short_rules: Rules = Rules.new(short_state)
	check(Grid.distance(Vector2i(1, 1), Vector2i(3, 1)) == 2, "Detour target has direct distance 2")
	check(not short_rules.reachable(1, 1).has(Vector2i(3, 1)), "Three-step detour is not reachable with allowance 2")
	check(short_rules.path_to(1, 1, Vector2i(3, 1)).is_empty(), "Unaffordable detour has no preview")
	_reject_move(short_state, short_rules, 1, 1, Vector2i(3, 1), "Detour costs actual path length")
	var long_state: State = _detour_state(3)
	var long_rules: Rules = Rules.new(long_state)
	var before: String = _snapshot(long_state)
	var path: Array[Vector2i] = long_rules.path_to(1, 1, Vector2i(3, 1))
	var expected_path: Array[Vector2i] = [Vector2i(1, 1), Vector2i(2, 0), Vector2i(3, 0), Vector2i(3, 1)]
	check(path == expected_path, "Stable neighbor order selects deterministic shortest detour")
	check(long_rules.path_to(1, 1, Vector2i(3, 1)) == path, "Repeated path query is deterministic")
	check(_snapshot(long_state) == before, "Pathfinding does not mutate any state")
	_check_path(long_state, 1, path, Vector2i(1, 1), Vector2i(3, 1), "Three-step detour")
	var result: Rules.Result = long_rules.try_move(1, 1, Vector2i(3, 1))
	check(result.success and result.path == expected_path, "Allowance 3 accepts shortest detour")
	check(long_state.units[1].moved and long_state.units[1].hex == Vector2i(3, 1), "Detour consumes action and arrives")

func _test_turns() -> void:
	var state: State = State.new()
	var rules: Rules = Rules.new(state)
	check(rules.try_move(1, 1, Vector2i(1, 0)).success, "Player 1 infantry moves")
	check(rules.try_move(1, 2, Vector2i(2, 2)).success, "Player 1 scout moves independently")
	check(rules.try_end_turn(1).success, "Player 1 ends turn")
	check(state.active_player == 2 and state.round_number == 1, "Player 2 starts in the same round")
	check(state.units[1].moved and state.units[2].moved, "Outgoing player actions stay spent")
	check(not state.units[3].moved and not state.units[4].moved, "Incoming Player 2 units ready")
	_reject_end_turn(state, rules, 1, "Previous player cannot end new turn")
	_reject_move(state, rules, 1, 1, Vector2i(2, 0), "Previous player cannot move")
	check(rules.try_move(2, 3, Vector2i(8, 9)).success, "Player 2 infantry moves")
	check(rules.try_move(2, 4, Vector2i(7, 7)).success, "Player 2 scout moves")
	check(rules.try_end_turn(2).success, "Player 2 ends turn")
	check(state.active_player == 1 and state.round_number == 2, "Round increments after Player 2 only")
	check(not state.units[1].moved and not state.units[2].moved, "Incoming Player 1 actions reset")
	check(state.units[3].moved and state.units[4].moved, "Player 2 actions are not reset early")
	check(state.units[1].hex == Vector2i(1, 0) and state.units[3].hex == Vector2i(8, 9), "Turn switch preserves positions")
	check(rules.try_move(1, 1, Vector2i(2, 0)).success, "Player 1 can move again next round")
	check(rules.try_end_turn(1).success, "Second Player 1 turn ends")
	check(state.active_player == 2 and state.round_number == 2, "Player 1 end does not increment round")
	check(not state.units[3].moved and not state.units[4].moved, "Player 2 actions reset on next incoming turn")
	check(state.units[1].moved, "Only incoming player is reset")
	check(rules.try_end_turn(2).success and state.round_number == 3, "Round progression continues")

func _equivalence_state(case_index: int) -> State:
	if case_index == 2:
		return _detour_state(3)
	if case_index == 3:
		return _trapped_state()
	var state: State = State.new()
	if case_index == 5:
		state.units[1].moved = true
	elif case_index == 6:
		state.active_player = 2
	return state

func _test_reachable_matches_validation() -> void:
	# A fresh fixture per destination prevents the first successful command from
	# spending the action and contaminating later acceptance comparisons.
	for case_index in range(8):
		var actor: int = 2 if case_index == 6 else 1
		var unit_id: int = 1
		if case_index == 1:
			unit_id = 2
		elif case_index == 4 or case_index == 6:
			unit_id = 3
		elif case_index == 7:
			unit_id = 999
		var state: State = _equivalence_state(case_index)
		var rules: Rules = Rules.new(state)
		var before: String = _snapshot(state)
		var reachable: Array[Vector2i] = rules.reachable(actor, unit_id)
		check(_snapshot(state) == before, "Reachability query is read only")
		check(rules.reachable(actor, unit_id) == reachable, "Reachability order is deterministic")
		var unique: Array[Vector2i] = []
		for hex: Vector2i in reachable:
			check(not unique.has(hex), "Reachability has no duplicates")
			check(Grid.contains(hex) and state.unit_at(hex) == null, "Highlights contain only valid empty tiles")
			unique.append(hex)
		for q in range(Grid.WIDTH):
			for r in range(Grid.HEIGHT):
				var destination: Vector2i = Vector2i(q, r)
				var candidate: State = _equivalence_state(case_index)
				var candidate_rules: Rules = Rules.new(candidate)
				var candidate_before: String = _snapshot(candidate)
				var preview: Array[Vector2i] = candidate_rules.path_to(actor, unit_id, destination)
				var result: Rules.Result = candidate_rules.try_move(actor, unit_id, destination)
				var context: String = "Case %d destination %s" % [case_index, destination]
				check(result.success == reachable.has(destination), context + ": highlight equals acceptance")
				check((not preview.is_empty()) == result.success, context + ": preview equals acceptance")
				if result.success:
					check(result.path == preview, context + ": command uses preview")
					check(candidate.units[unit_id].hex == destination and candidate.units[unit_id].moved, context + ": accepted command applies")
				else:
					check(not result.reason.is_empty(), context + ": rejected command gives reason")
					check(_snapshot(candidate) == candidate_before, context + ": rejected command changes nothing")

func _run() -> void:
	_test_initial_state_and_move()
	_test_rejections()
	_test_paths()
	_test_turns()
	_test_reachable_matches_validation()
	print("Movement checks complete: ", checks, " checks, 800 reachability/command comparisons; failures=", failures)
	quit(0 if failures == 0 else 1)
