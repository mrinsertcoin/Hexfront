extends SceneTree

const Grid = preload("res://scripts/core/hex_grid.gd")
const Main = preload("res://scenes/main.tscn")
var failures: int = 0

func _initialize() -> void:
	call_deferred("_run")

func check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)

func _run() -> void:
	for q in range(-10, 20):
		for r in range(-10, 20):
			var hex := Vector2i(q, r)
			check(Grid.from_world(Grid.to_world(hex)) == hex, "Round trip: %s" % hex)
			var neighbors: Array[Vector2i] = []
			for direction: Vector2i in Grid.DIRECTIONS:
				var neighbor: Vector2i = hex + direction
				check(not neighbors.has(neighbor), "Duplicate neighbor")
				neighbors.append(neighbor)
				check(Grid.distance(hex, neighbor) == 1, "Adjacency distance")
				check(is_equal_approx(Grid.to_world(hex).distance_to(Grid.to_world(neighbor)), Grid.SQRT_3), "Adjacent world spacing")
				check(Grid.DIRECTIONS.has(-direction), "Reciprocal adjacency")
				check(Grid.from_world(Grid.to_world(hex).lerp(Grid.to_world(neighbor), 0.49)) == hex, "Inside edge")
				check(Grid.from_world(Grid.to_world(hex).lerp(Grid.to_world(neighbor), 0.51)) == neighbor, "Across edge")
	check(not Grid.contains(Vector2i(-1, 0)) and not Grid.contains(Vector2i(10, 0)), "Q bounds")
	check(not Grid.contains(Vector2i(0, -1)) and not Grid.contains(Vector2i(0, 10)), "R bounds")
	var board = Main.instantiate()
	root.add_child(board)
	await process_frame
	check(board.tiles.size() == 100, "100 tiles")
	for size: float in [6.0, 31.0, 60.0]:
		board.camera.size = size
		board.camera.position += Vector3(2, 0, -1)
		for q in range(10):
			for r in range(10):
				var hex := Vector2i(q, r)
				var screen: Vector2 = board.camera.unproject_position(Grid.to_world(hex) + Vector3(0, board.TOP_Y, 0))
				board.select_at(screen)
				check(board.selected == hex, "Picking %s at zoom %s" % [hex, size])
				check(board.coordinate_label.text.begins_with("Selected: (q=%d, r=%d)" % [q, r]), "Coordinate label")
				check(board.tiles[hex].material_override == board.selected_material, "Selection highlight")
	var gap: Vector3 = Grid.to_world(Vector2i(4, 4)).lerp(Grid.to_world(Vector2i(5, 4)), 0.5)
	board.select_at(board.camera.unproject_position(gap + Vector3(0, board.TOP_Y, 0)))
	check(board.selected == board.NONE, "Gap clears selection")
	board.select_at(board.camera.unproject_position(Vector3(-10, board.TOP_Y, -10)))
	check(board.selected == board.NONE, "Outside clears selection")
	print("Smoke checks complete: 900 round trips, 5400 neighbor checks, 300 camera picks; failures=", failures)
	quit(0 if failures == 0 else 1)

