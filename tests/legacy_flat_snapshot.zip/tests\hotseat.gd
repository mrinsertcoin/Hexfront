extends SceneTree

const Main = preload("res://scenes/main.tscn")
var failures: int = 0
var board: HexBoard

func _initialize() -> void:
	call_deferred("_run")

func check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)

func _screen(hex: Vector2i) -> Vector2:
	return board.camera.unproject_position(HexGrid.to_world(hex) + Vector3(0, board.TOP_Y, 0))

# Synthetic viewport events exercise Godot's GUI/unhandled-input routing.
# These do not establish that a physical mouse works on the host desktop.
func click(position: Vector2, button_index: MouseButton = MOUSE_BUTTON_LEFT) -> void:
	var motion := InputEventMouseMotion.new()
	motion.position = position
	motion.global_position = position
	root.push_input(motion, true)
	for pressed: bool in [true, false]:
		var event := InputEventMouseButton.new()
		event.position = position
		event.global_position = position
		event.button_index = button_index
		event.pressed = pressed
		event.button_mask = MOUSE_BUTTON_MASK_LEFT if pressed and button_index == MOUSE_BUTTON_LEFT else 0
		root.push_input(event, true)

func _run() -> void:
	root.size = Vector2i(1152, 648)
	board = Main.instantiate() as HexBoard
	# Instant presentation keeps this rules/input regression suite synchronous.
	board.animate_movement = false
	root.add_child(board)
	board._new_match("Hotseat")
	board.set_process(false)
	await process_frame
	await process_frame
	check(board.unit_views.size() == 8, "Six military + two headquarters views")
	check(board.unit_views[1].get_node("visual_root/ModelRoot").get_child_count() == 1 and board.unit_views[2].get_node("visual_root/ModelRoot").get_child_count() == 1, "Each type has one imported model")
	for id: int in [1, 2]:
		click(_screen(board.game_state.units[id].hex))
		check(board.selected_unit_id == id, "Left click selects P1 unit")
		check(board.unit_label.text.contains("Ready"), "Ready label")
		check(board.reachable_tiles == board.rules.reachable(1, id), "View highlights rules destinations")
		for hex: Vector2i in board.reachable_tiles:
			check(board.tiles[hex].material_override == board.reachable_material or board.tiles[hex].material_override == board.path_material, "Reachable tile is highlighted")
		var destination: Vector2i = Vector2i(1, 0) if id == 1 else Vector2i(2, 2)
		click(_screen(destination), MOUSE_BUTTON_RIGHT)
		check(board.game_state.units[id].hex == destination and board.game_state.units[id].moved, "Right click applies movement")
		check(board.unit_views[id].position.is_equal_approx(HexGrid.to_world(destination) + Vector3(0, board.TOP_Y, 0)), "Visual follows logical position")
		check(board.reachable_tiles.is_empty() and board.unit_label.text.contains("Moved"), "Spent unit has no highlights")
		click(_screen(Vector2i(3, id)), MOUSE_BUTTON_RIGHT)
		check(board.game_state.units[id].hex == destination, "Second right click cannot move")
		check(board.feedback_label.text.contains("already moved"), "Readable rejected-move feedback")
	click(_screen(Vector2i(8, 8)))
	check(board.selected_unit_id == 3 and board.unit_label.text.contains("inspection only"), "Enemy inspection")
	check(board.reachable_tiles.is_empty(), "Enemy has no movement highlights")
	click(_screen(Vector2i(8, 9)), MOUSE_BUTTON_RIGHT)
	check(board.game_state.units[3].hex == Vector2i(8, 8), "Enemy cannot be moved")
	check(board.feedback_label.text.contains("own units"), "Enemy rejection feedback")
	var escape := InputEventKey.new()
	escape.pressed = true
	escape.physical_keycode = KEY_ESCAPE
	root.push_input(escape, true)
	check(board.selected_unit_id == -1 and board.reachable_tiles.is_empty(), "Escape clears unit selection")
	escape.pressed = false
	root.push_input(escape, true)
	click(_screen(Vector2i(2, 1)))
	click(board.end_turn_button.get_global_rect().get_center())
	check(board.game_state.active_player == 2 and board.game_state.round_number == 1, "End Turn button switches player")
	check(board.selected_unit_id == -1 and board.selected == board.NONE and board.reachable_tiles.is_empty(), "UI click clears selection without board click-through")
	await process_frame
	for id: int in [3, 4]:
		click(_screen(board.game_state.units[id].hex))
		var destination: Vector2i = Vector2i(8, 9) if id == 3 else Vector2i(7, 7)
		click(_screen(destination), MOUSE_BUTTON_RIGHT)
		check(board.game_state.units[id].hex == destination and board.game_state.units[id].moved, "P2 can move both units")
	click(board.end_turn_button.get_global_rect().get_center())
	check(board.game_state.active_player == 1 and board.game_state.round_number == 2, "Full hotseat round")
	for id: int in [1, 2]:
		click(_screen(board.game_state.units[id].hex))
		check(not board.game_state.units[id].moved and not board.reachable_tiles.is_empty(), "P1 movement restored")
	var selected_before_ui: int = board.selected_unit_id
	click(board.hud_panel.get_global_rect().position + Vector2(10, 10))
	check(board.selected_unit_id == selected_before_ui, "HUD panel consumes left clicks")
	click(board.hud_panel.get_global_rect().position + Vector2(10, 10), MOUSE_BUTTON_RIGHT)
	check(not board.game_state.units[selected_before_ui].moved, "HUD panel consumes right clicks")
	click(board.coordinate_label.get_global_rect().get_center())
	check(board.selected_unit_id == selected_before_ui, "Coordinate display consumes clicks")
	var gap: Vector3 = HexGrid.to_world(Vector2i(4, 4)).lerp(HexGrid.to_world(Vector2i(5, 4)), 0.5)
	click(board.camera.unproject_position(gap + Vector3(0, board.TOP_Y, 0)))
	check(board.selected_unit_id == -1 and board.selected == board.NONE, "Gap clears all selection")
	print("Hotseat scene checks complete; failures=", failures)
	quit(0 if failures == 0 else 1)
