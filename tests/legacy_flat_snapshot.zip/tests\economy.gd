extends SceneTree
const Snapshot = preload("res://tests/test_state.gd")
var failures: int = 0

func _initialize() -> void:
	call_deferred("_run")

func check(ok: bool, message: String) -> void:
	if not ok:
		failures += 1
		push_error(message)

func reject(state: GameState, actor: int, hq: int, kind: String, hex: Vector2i) -> void:
	var before: String = Snapshot.snapshot(state)
	var result: GameRules.Result = GameRules.new(state).try_recruit(actor, hq, kind, hex)
	check(not result.success and not result.reason.is_empty(), "Recruit request rejected with a reason")
	check(Snapshot.snapshot(state) == before, "Rejected recruitment leaves every field unchanged")

func _run() -> void:
	var state := GameState.new()
	var rules := GameRules.new(state)
	check(state.materials == {1: 11, 2: 8}, "Initial income included in core initialization")
	var initial: String = Snapshot.snapshot(state)
	state.start_turn()
	rules._start_turn()
	check(Snapshot.snapshot(state) == initial, "Turn-start effects are idempotent")
	for kind: String in UnitTypes.COSTS:
		rules.restart_match()
		var id: int = state.next_id
		var before_query: String = Snapshot.snapshot(state)
		check(rules.recruit_destinations(1, 100, kind).has(Vector2i.ZERO), "Legal placement query")
		check(Snapshot.snapshot(state) == before_query, "Recruit query is side-effect free")
		check(rules.try_recruit(1, 100, kind, Vector2i.ZERO).success, "Recruit each unit type")
		check(state.units[id].hp == state.units[id].max_hp and state.units[id].ready_next_turn, "Recruit arrives at full HP, ready next turn")
		check(state.materials[1] == 11 - int(UnitTypes.COSTS[kind]) and not state.structures[100].recruit_available, "Deduct exact centralized cost and consume allowance")
		check(not rules.try_move(1, id, Vector2i(1, 0)).success, "Recruit cannot move immediately")
		state.units[3].hex = Vector2i(1, 0)
		check(not rules.try_attack(1, id, 3).success, "Recruit cannot attack immediately")
		reject(state, 1, 100, kind, Vector2i(0, 2))
		check(rules.try_end_turn(1).success and state.materials[2] == 11, "P2 first income")
		check(state.units[id].ready_next_turn, "Recruit still waits during opponent turn")
		check(rules.try_end_turn(2).success, "Return to recruiter")
		check(not state.units[id].ready_next_turn and not state.units[id].moved and not state.units[id].attacked, "Incoming turn restores both recruit actions")
		check(state.materials[1] == 14 - int(UnitTypes.COSTS[kind]) and state.structures[100].recruit_available, "Income and allowance restored once")
	rules.restart_match()
	reject(state, 2, 101, "Scout", Vector2i(9, 9))
	reject(state, 1, 101, "Scout", Vector2i(9, 9))
	reject(state, 1, 999, "Scout", Vector2i.ZERO)
	reject(state, 1, 100, "Unknown", Vector2i.ZERO)
	reject(state, 1, 100, "Scout", Vector2i(-1, 1))
	reject(state, 1, 100, "Scout", Vector2i(4, 4))
	reject(state, 1, 100, "Scout", Vector2i(1, 1))
	reject(state, 1, 100, "Scout", Vector2i(0, 1))
	state.materials[1] = 0
	reject(state, 1, 100, "Scout", Vector2i.ZERO)
	rules.restart_match()
	state.structures[100].hp = 0
	reject(state, 1, 100, "Scout", Vector2i.ZERO)
	rules.restart_match()
	state.structures[100].structure_type = "Depot"
	reject(state, 1, 100, "Scout", Vector2i.ZERO)
	rules.restart_match()
	for hex: Vector2i in rules.recruit_destinations(1, 100, "Scout"):
		var id: int = state.allocate_id()
		state.units[id] = GameState.Unit.new(id, 1, "Infantry", hex)
	check(rules.recruit_destinations(1, 100, "Scout").is_empty(), "Blocked HQ has no placements")
	for direction: Vector2i in HexGrid.DIRECTIONS:
		reject(state, 1, 100, "Scout", state.structures[100].hex + direction)
	rules.restart_match()
	state.next_id = 100
	check(rules.try_recruit(1, 100, "Scout", Vector2i.ZERO).success and state.units.has(102), "ID allocation skips existing structure IDs")
	rules.restart_match()
	check(not rules.reachable(1, 1).has(Vector2i(0, 1)), "HQ blocks movement")
	check(not rules.try_move(1, 1, Vector2i(0, 1)).success, "HQ cannot be occupied by movement")
	check(not rules.try_move(1, 100, Vector2i.ZERO).success and not rules.try_attack(1, 100, 3).success, "HQ cannot move or attack")

	for winner: int in [1, 2]:
		rules.restart_match()
		state.active_player = winner
		state.units.clear()
		var enemy_hq: int = 101 if winner == 1 else 100
		var target_hex: Vector2i = state.structures[enemy_hq].hex
		var source_hex: Vector2i = target_hex + Vector2i(-1, 0) if winner == 1 else target_hex + Vector2i(1, 0)
		state.units[1] = GameState.Unit.new(1, winner, "Gunner", source_hex)
		state.units[2] = GameState.Unit.new(2, 3 - winner, "Scout", Vector2i(5, 5))
		state.units[4] = GameState.Unit.new(4, winner, "Scout", Vector2i(4, 4))
		state.structures[enemy_hq].hp = 1
		var before: String = Snapshot.snapshot(state)
		var preview: GameRules.Result = rules.preview_attack(winner, 1, enemy_hq)
		check(preview.killed and preview.winner_id == winner and Snapshot.snapshot(state) == before, "HQ lethal preview is pure")
		check(rules.try_attack(winner, 1, enemy_hq).winner_id == winner and state.units.has(2), "HQ death wins with enemy troops surviving")
		before = Snapshot.snapshot(state)
		check(not rules.try_move(winner, 4, Vector2i(4, 5)).success, "No moves after victory")
		check(not rules.try_attack(winner, 4, 2).success, "No attacks after victory")
		check(not rules.try_end_turn(winner).success, "No turns after victory")
		reject(state, winner, 100 if winner == 1 else 101, "Scout", Vector2i.ZERO)
		check(Snapshot.snapshot(state) == before, "Victory rejects all mutation")
		for repetition in range(3):
			rules.restart_match()
			check(Snapshot.snapshot(state) == initial, "Repeated restart restores exact economy and IDs")
	print("Economy checks: income, recruitment, blockers, HQ victory, immutable rejection, restart; failures=", failures)
	quit(0 if failures == 0 else 1)

