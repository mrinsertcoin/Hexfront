class_name HexBoard
extends Node3D

const Grid = preload("res://scripts/core/hex_grid.gd")
const VisualMap = preload("res://scripts/view/visual_map.gd")
var visual_map: VisualMap = VisualMap.new()
const TILE_RADIUS: float = 0.95
const TOP_Y: float = 0.15
const NONE: Vector2i = Vector2i(-1, -1)

var selected: Vector2i = NONE
var tiles: Dictionary[Vector2i, MeshInstance3D] = {}
var tiles_base_materials: Dictionary[Vector2i, StandardMaterial3D] = {}
var camera: Camera3D
var coordinate_label: Label
var normal_material: StandardMaterial3D
var selected_material: StandardMaterial3D
var reachable_material: StandardMaterial3D
var path_material: StandardMaterial3D
var attack_material: StandardMaterial3D
var game_state: GameState = GameState.new()
var rules: GameRules = GameRules.new(game_state)
var unit_views: Dictionary[int, EntityView] = {}
@export var animate_movement: bool = true
var health_fills: Dictionary[int, MeshInstance3D] = {}
var attack_tiles: Array[Vector2i] = []
var restart_button: Button
var attack_preview_label: Label
var selected_unit_id: int = -1
var selected_structure_id: int = -1
var reachable_tiles: Array[Vector2i] = []
var preview_path: Array[Vector2i] = []
var hover_hex: Vector2i = NONE
var hud_panel: PanelContainer
var turn_label: Label
var unit_label: Label
var feedback_label: Label
var end_turn_button: Button
var feedback_seconds: float = 0.0
var placement_mode: bool = false
var recruit_choice: String = ""
var recruit_hq_id: int = -1
var materials_label: Label
var recruit_highlights: Array[Vector2i] = []
var recruit_box: VBoxContainer
var match_mode: String = "Vs AI" # "Vs AI" or "Hotseat"
var player_controllers: Dictionary[int, String] = {1: "Human", 2: "AI"}

# AI runtime state
var _ai_running: bool = false
var _ai_token: int = 0
var _ai_delay: float = 0.25
const SimpleAI = preload("res://scripts/ai/simple_ai.gd")
var ai_agent: SimpleAI = SimpleAI.new()

# Camera rig parameters (Milestone 7)
@export var cam_min_pitch: float = 30.0
@export var cam_max_pitch: float = 75.0
@export var cam_default_pitch: float = 60.0
@export var cam_min_distance: float = 12.0
@export var cam_max_distance: float = 60.0
@export var cam_default_distance: float = 31.0
@export var cam_mouse_rotation_sensitivity: float = 0.3
@export var cam_mouse_pitch_sensitivity: float = 0.2
@export var cam_pan_speed: float = 20.0
@export var cam_zoom_speed: float = 1.15
@export var cam_rotation_speed_deg: float = 90.0 # degrees per second for Q/E
@export var cam_smoothing: float = 12.0

var cam_focus: Vector3 = Vector3.ZERO
var cam_target_focus: Vector3 = Vector3.ZERO
var cam_yaw: float = 0.0
var cam_target_yaw: float = 0.0
var cam_pitch: float = cam_default_pitch
var cam_target_pitch: float = cam_default_pitch
var cam_distance: float = cam_default_distance
var cam_target_distance: float = cam_default_distance

var _is_middle_dragging: bool = false
var _last_mouse_pos: Vector2 = Vector2.ZERO


func _ready() -> void:
	normal_material = _material(Color("#468b91"))
	selected_material = _material(Color("#ffd166"))
	reachable_material = _material(Color("#578d4d"))
	path_material = _material(Color("#82e1ed"))
	attack_material = _material(Color("#d46bbe"))
	var mesh: ArrayMesh = _make_prism_mesh(6, TILE_RADIUS, TOP_Y)
	for q in range(Grid.WIDTH):
		for r in range(Grid.HEIGHT):
			var hex := Vector2i(q, r)
			var tile := MeshInstance3D.new()
			tile.mesh = mesh
			# Assign deterministic visual variant per tile
			var base_mat: StandardMaterial3D = _tile_material_for(hex)
			tile.material_override = base_mat
			tiles_base_materials[hex] = base_mat
			tile.position = Grid.to_world(hex)
			add_child(tile)
			tiles[hex] = tile
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL

	# Initialize camera rig state from default values and board center
	# Compute board center based on grid extents
	var min_world := Grid.to_world(Vector2i(0, 0))
	var max_world := Grid.to_world(Vector2i(Grid.WIDTH - 1, Grid.HEIGHT - 1))
	var center := min_world.lerp(max_world, 0.5)
	cam_focus = center
	cam_target_focus = center
	cam_yaw = 0.0
	cam_target_yaw = 0.0
	cam_pitch = cam_default_pitch
	cam_target_pitch = cam_default_pitch
	cam_distance = cam_default_distance
	cam_target_distance = cam_default_distance

	# Camera node (orthographic)
	camera.current = true
	add_child(camera)
	_reset_camera()
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color("#15212d")
	# Add gentle ambient so PBR models are visible
	environment.environment.ambient_light_color = Color(0.7, 0.75, 0.8)
	environment.environment.ambient_light_energy = 0.8
	# Slight tone mapping/adjustment for presentation
	environment.environment.adjustment_enabled = true
	environment.environment.adjustment_brightness = 1.0
	environment.environment.adjustment_contrast = 1.05
	add_child(environment)
	# Add a directional light to illuminate imported models
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.light_energy = 2.0
	sun.rotation_degrees = Vector3(-60, 30, 0)
	add_child(sun)
	var hud := CanvasLayer.new()
	add_child(hud)
	coordinate_label = Label.new()
	coordinate_label.position = Vector2(18, 16)
	coordinate_label.add_theme_font_size_override("font_size", 22)
	coordinate_label.mouse_filter = Control.MOUSE_FILTER_STOP
	coordinate_label.mouse_force_pass_scroll_events = false
	hud.add_child(coordinate_label)
	_create_turn_hud(hud)
	restart_match()

func _sync_units() -> void:
	for id: int in unit_views.keys():
		if not game_state.units.has(id) and not game_state.structures.has(id):
			remove_child(unit_views[id])
			unit_views[id].queue_free()
			unit_views.erase(id)
			health_fills.erase(id)
	for unit: GameState.Unit in game_state.units.values():
		if not unit_views.has(unit.id):
			_create_entity_view(unit.id, unit.owner_id, unit.unit_type, false)
		_update_entity_view(unit.id, unit.hex, unit.hp, unit.max_hp)
	for structure: GameState.Structure in game_state.structures.values():
		if not unit_views.has(structure.id):
			_create_entity_view(structure.id, structure.owner_id, structure.structure_type, true)
		_update_entity_view(structure.id, structure.hex, structure.hp, structure.max_hp)

func _create_entity_view(id: int, owner_id: int, kind: String, is_structure: bool) -> void:
	var view := EntityView.new()
	view.name = "Entity_%d" % id
	add_child(view)
	unit_views[id] = view
	var packed: PackedScene = visual_map.structure_scene(kind) if is_structure else visual_map.unit_scene(kind)
	var wrapper: Node3D = packed.instantiate() as Node3D if packed != null else Node3D.new()
	wrapper.name = "visual_root"
	view.add_child(wrapper)
	var model_root: Node3D = wrapper.get_node_or_null("ModelRoot") as Node3D
	if model_root == null:
		model_root = Node3D.new()
		model_root.name = "ModelRoot"
		wrapper.add_child(model_root)
	# Preserve authored wrapper children, skeletons and animation tracks.
	if model_root.get_child_count() == 0:
		var asset: PackedScene = visual_map.asset_scene(kind)
		if asset != null:
			model_root.add_child(asset.instantiate())
	if model_root.get_child_count() == 0:
		var placeholder := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(1.1, 0.7, 1.1) if is_structure else Vector3(0.6, 0.65, 0.6)
		placeholder.mesh = box
		placeholder.position.y = box.size.y / 2.0
		placeholder.material_override = _material(_owner_color(owner_id))
		model_root.add_child(placeholder)
	_apply_team_accent(model_root, owner_id)
	# Ownership remains readable even on textured assets without an accent slot.
	var team_ring := MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.64
	ring_mesh.outer_radius = 0.70
	team_ring.mesh = ring_mesh
	team_ring.scale.y = 0.15
	team_ring.position.y = 0.025
	team_ring.material_override = _material(_owner_color(owner_id))
	wrapper.add_child(team_ring)
	var background := MeshInstance3D.new()
	var bar := BoxMesh.new()
	bar.size = Vector3(0.94, 0.03, 0.13)
	background.mesh = bar
	background.position = Vector3(0, 0.09, 0.63)
	background.material_override = _material(Color("#101820"))
	view.add_child(background)
	var fill := MeshInstance3D.new()
	var fill_mesh := BoxMesh.new()
	fill_mesh.size = Vector3(0.88, 0.03, 0.08)
	fill.mesh = fill_mesh
	fill.position = Vector3(0, 0.12, 0.63)
	fill.material_override = _material(Color("#b5ed75"))
	view.add_child(fill)
	health_fills[id] = fill
	view.configure(wrapper)
	view.movement_finished.connect(_refresh_display)

func _update_entity_view(id: int, hex: Vector2i, hp: int, max_hp: int) -> void:
	# Ground-origin wrapper; logical coordinates never depend on model transforms.
	unit_views[id].sync_position(Grid.to_world(hex) + Vector3(0, TOP_Y, 0))
	var fraction: float = float(hp) / max_hp
	health_fills[id].scale.x = fraction
	health_fills[id].position.x = -0.44 * (1.0 - fraction)

func _create_turn_hud(hud: CanvasLayer) -> void:
	hud_panel = PanelContainer.new()
	hud_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	hud_panel.mouse_force_pass_scroll_events = false
	hud.add_child(hud_panel)
	var margin := MarginContainer.new()
	for side: String in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 10)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_panel.add_child(margin)
	var column := VBoxContainer.new()
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_theme_constant_override("separation", 8)
	margin.add_child(column)
	turn_label = _hud_label(column)
	turn_label.add_theme_font_size_override("font_size", 22)
	materials_label = _hud_label(column)
	var modes := HBoxContainer.new()
	for mode: String in ["Hotseat", "Vs AI"]:
		var button := Button.new()
		button.text = mode + " (new)"
		button.focus_mode = Control.FOCUS_NONE
		button.pressed.connect(_new_match.bind(mode))
		modes.add_child(button)
	column.add_child(modes)
	end_turn_button = Button.new()
	end_turn_button.focus_mode = Control.FOCUS_NONE
	end_turn_button.pressed.connect(request_end_turn)
	column.add_child(end_turn_button)
	restart_button = Button.new()
	restart_button.text = "Restart"
	restart_button.focus_mode = Control.FOCUS_NONE
	restart_button.pressed.connect(restart_match)
	column.add_child(restart_button)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	var details := VBoxContainer.new()
	details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details.mouse_filter = Control.MOUSE_FILTER_IGNORE
	details.add_theme_constant_override("separation", 10)
	scroll.add_child(details)
	var legend: Label = _hud_label(details)
	legend.text = "Blue: P1 | Red: P2\nGreen: move | Cyan: path\nPurple: attack | Gold: selection"
	unit_label = _hud_label(details)
	unit_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	unit_label.custom_minimum_size.x = 270
	recruit_box = VBoxContainer.new()
	recruit_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	details.add_child(recruit_box)
	attack_preview_label = _hud_label(details)
	attack_preview_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	attack_preview_label.custom_minimum_size.y = 48
	feedback_label = _hud_label(details)
	feedback_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	feedback_label.custom_minimum_size.y = 54
	_layout_hud()
	get_viewport().size_changed.connect(_layout_hud)

func _hud_label(parent: Control) -> Label:
	var label := Label.new()
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(label)
	return label

func _new_match(mode: String) -> void:
	match_mode = mode
	player_controllers = {1: "Human", 2: "Human" if mode == "Hotseat" else "AI"}
	restart_match()

func _layout_hud() -> void:
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	hud_panel.position = Vector2(maxf(0.0, viewport_size.x - 330.0), 12.0)
	hud_panel.size = Vector2(318, maxf(240.0, viewport_size.y - 24.0))

func _clear_recruit_box() -> void:
	while recruit_box.get_child_count() > 0:
		var child := recruit_box.get_child(0)
		recruit_box.remove_child(child)
		child.queue_free()

func _material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	return material

func _tile_material_for(hex: Vector2i) -> StandardMaterial3D:
	# Deterministic pseudo-random choice based on coordinates.
	var q := int(hex.x)
	var r := int(hex.y)
	var seed: int = int((q * 73856093) ^ (r * 19349663) ^ 0x9e3779b9)
	var v: int = int(abs(seed) % 100)
	if v < 50:
		return _material(Color("#6b4f2f")) # dry earth
	elif v < 70:
		return _material(Color("#667f3a")) # sparse grass
	elif v < 85:
		return _material(Color("#5d5d5d")) # rocky
	elif v < 95:
		return _material(Color("#7a5b3a")) # cracked/damaged
	else:
		return _material(Color("#555a66")) # industrial

func _make_prism_mesh(sides: int, radius: float, half_height: float) -> ArrayMesh:
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for index in range(sides):
		var angle_a: float = deg_to_rad(30.0 + index * (360.0 / sides))
		var angle_b: float = deg_to_rad(30.0 + (index + 1) * (360.0 / sides))
		var a := Vector3(cos(angle_a) * radius, half_height, sin(angle_a) * radius)
		var b := Vector3(cos(angle_b) * radius, half_height, sin(angle_b) * radius)
		var low_a := Vector3(a.x, -half_height, a.z)
		var low_b := Vector3(b.x, -half_height, b.z)
		for vertex: Vector3 in [Vector3(0, half_height, 0), b, a, a, b, low_a, b, low_b, low_a]:
			surface.add_vertex(vertex)
	surface.generate_normals()
	return surface.commit()

func _process(delta: float) -> void:
	if feedback_seconds > 0.0:
		feedback_seconds -= delta
		if feedback_seconds <= 0.0:
			feedback_label.text = ""
	# Camera keyboard pan (WASD / arrows) - pan moves the focus point relative to camera yaw
	var horizontal: float = float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT))
	var vertical: float = float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)) - float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN))
	# Compute flattened forward/right from camera
	var cam_forward: Vector3 = -camera.global_transform.basis.z
	cam_forward.y = 0
	if cam_forward.length() == 0:
		cam_forward = Vector3(0, 0, -1)
	cam_forward = cam_forward.normalized()
	var cam_right: Vector3 = camera.global_transform.basis.x
	cam_right.y = 0
	cam_right = cam_right.normalized()
	var pan_input := cam_right * horizontal + cam_forward * vertical
	if pan_input.length() > 0:
		# scale pan speed slightly with distance for usability
		var scale: float = clamp(cam_distance / cam_default_distance, 0.5, 2.0)
		cam_target_focus += pan_input.normalized() * cam_pan_speed * scale * delta

	# Keyboard rotate (Q/E)
	if Input.is_physical_key_pressed(KEY_Q):
		cam_target_yaw -= cam_rotation_speed_deg * delta
	if Input.is_physical_key_pressed(KEY_E):
		cam_target_yaw += cam_rotation_speed_deg * delta

	# Smoothly interpolate core camera state
	var t: float = clamp(cam_smoothing * delta, 0.0, 1.0)
	cam_focus = cam_focus.lerp(cam_target_focus, t)
	cam_yaw = rad_to_deg(lerp_angle(deg_to_rad(cam_yaw), deg_to_rad(cam_target_yaw), t))
	cam_pitch = lerp(cam_pitch, cam_target_pitch, t)
	cam_distance = lerp(cam_distance, cam_target_distance, t)

	_update_camera_transform(delta)
	_update_preview()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		if not button.pressed and button.button_index != MOUSE_BUTTON_MIDDLE:
			return
		# Only middle-button release affects drag state.
		match button.button_index:
			MOUSE_BUTTON_LEFT:
				if placement_mode:
					handle_recruit_click(button.position)
				else:
					# Allow inspection during AI turns but block other interactions
					select_at(button.position)
			MOUSE_BUTTON_RIGHT:
				if placement_mode:
					_cancel_recruit()
				else:
					# Block action input when it's an AI-controlled player's turn
					if player_controllers.get(game_state.active_player, "Human") == "AI":
						return
					request_action_at(button.position)
			MOUSE_BUTTON_WHEEL_UP:
				# Zoom in (target distance)
				if button.pressed:
					cam_target_distance = max(cam_min_distance, cam_target_distance / cam_zoom_speed)
			MOUSE_BUTTON_WHEEL_DOWN:
				if button.pressed:
					cam_target_distance = min(cam_max_distance, cam_target_distance * cam_zoom_speed)
			MOUSE_BUTTON_MIDDLE:
				if button.pressed:
					# begin middle-drag rotation
					_is_middle_dragging = true
					_last_mouse_pos = button.position
				else:
					# released
					_is_middle_dragging = false
	elif event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		# Middle-drag -> orbit/tilt
		if _is_middle_dragging and not (motion.button_mask & MOUSE_BUTTON_MASK_MIDDLE):
			_is_middle_dragging = false
		if _is_middle_dragging:
			var delta_mouse := motion.position - _last_mouse_pos
			_last_mouse_pos = motion.position
			cam_target_yaw += -delta_mouse.x * cam_mouse_rotation_sensitivity
			cam_target_pitch = clamp(cam_target_pitch + -delta_mouse.y * cam_mouse_pitch_sensitivity, cam_min_pitch, cam_max_pitch)
		else:
			# legacy middle-drag panning not used; keep camera pan to keyboard
			pass
	elif event is InputEventKey:
		var key := event as InputEventKey
		if key.pressed and key.physical_keycode == KEY_ESCAPE:
			if placement_mode:
				_cancel_recruit()
			else:
				clear_selection()
		elif key.pressed and key.physical_keycode == KEY_HOME:
			_reset_camera()

func pick_hex(screen_position: Vector2) -> Vector2i:
	var origin: Vector3 = camera.project_ray_origin(screen_position)
	var direction: Vector3 = camera.project_ray_normal(screen_position)
	var intersection: Variant = Plane(Vector3.UP, TOP_Y).intersects_ray(origin, direction)
	if intersection == null:
		return NONE
	var world: Vector3 = intersection
	var hex: Vector2i = Grid.from_world(world)
	if not Grid.contains(hex):
		return NONE
	# Reject the visible gaps between the smaller-than-cell hex prisms.
	var offset: Vector3 = world - Grid.to_world(hex)
	var x: float = absf(offset.x)
	var z: float = absf(offset.z)
	if x > Grid.SQRT_3 * TILE_RADIUS / 2.0 or x + Grid.SQRT_3 * z > Grid.SQRT_3 * TILE_RADIUS:
		return NONE
	return hex

func select_at(screen_position: Vector2) -> void:
	selected = pick_hex(screen_position)
	var unit: GameState.Unit = game_state.unit_at(selected)
	if unit != null:
		selected_unit_id = unit.id
		selected_structure_id = -1
	else:
		var s: GameState.Structure = game_state.structure_at(selected)
		if s != null:
			selected_structure_id = s.id
			selected_unit_id = -1
		else:
			selected_unit_id = -1
			selected_structure_id = -1
	_refresh_display()

func clear_selection() -> void:
	selected = NONE
	selected_unit_id = -1
	selected_structure_id = -1
	_cancel_recruit(false)
	_refresh_display()

func request_action_at(screen_position: Vector2) -> void:
	if _human_action_blocked():
		return
	if game_state.winner_id != 0:
		return
	# If placement mode is active, right click cancels and left handled elsewhere
	if placement_mode:
		return
	var target_entity := game_state.entity_at(pick_hex(screen_position))
	if target_entity != null and target_entity.owner_id != game_state.active_player and selected_unit_id != -1:
		var result: GameRules.Result = rules.try_attack(game_state.active_player, selected_unit_id, target_entity.id)
		_refresh_display()
		_feedback(result.reason)
	else:
		request_move_at(screen_position)

func request_move_at(screen_position: Vector2) -> void:
	if _human_action_blocked():
		return
	if placement_mode:
		# In placement mode left clicks are handled by placement logic
		return
	if selected_unit_id == -1:
		_feedback("Select one of your units first.")
		return
	var result: GameRules.Result = rules.try_move(game_state.active_player, selected_unit_id, pick_hex(screen_position))
	if result.success:
		selected = game_state.units[selected_unit_id].hex
		_present_move(selected_unit_id, result)
	_refresh_display()
	_feedback(result.reason)

func request_end_turn() -> void:
	if _human_action_blocked():
		return
	var result: GameRules.Result = rules.try_end_turn(game_state.active_player)
	if result.success:
		clear_selection()
	_feedback(result.reason)
	_queue_ai_turn()

func _reset_camera() -> void:
	cam_focus = Grid.to_world(Vector2i.ZERO).lerp(Grid.to_world(Vector2i(9, 9)), 0.5)
	cam_target_focus = cam_focus
	cam_yaw = 0.0
	cam_target_yaw = 0.0
	cam_pitch = cam_default_pitch
	cam_target_pitch = cam_default_pitch
	cam_distance = cam_default_distance
	cam_target_distance = cam_default_distance
	_is_middle_dragging = false
	_update_camera_transform(0.0)

func restart_match() -> void:
	_ai_token += 1
	_ai_running = false
	ai_agent.reset()
	rules.restart_match()
	for view: MeshInstance3D in unit_views.values():
		remove_child(view)
		view.queue_free()
	unit_views.clear()
	health_fills.clear()
	selected = NONE
	selected_unit_id = -1
	selected_structure_id = -1
	_cancel_recruit(false)
	feedback_seconds = 0.0
	feedback_label.text = ""
	_reset_camera()
	_refresh_display()
	_queue_ai_turn()

func _feedback(message: String) -> void:
	feedback_label.text = message
	feedback_seconds = 5.0

func _refresh_display() -> void:
	_sync_units()
	if selected_unit_id != -1 and not game_state.units.has(selected_unit_id):
		selected_unit_id = -1
		selected = NONE
	if selected_structure_id != -1 and not game_state.structures.has(selected_structure_id):
		selected_structure_id = -1
		selected = NONE
	if placement_mode and (game_state.winner_id != 0 or not game_state.structures.has(recruit_hq_id)):
		_cancel_recruit(false)
	var presenting: bool = is_presenting()
	var human_turn: bool = player_controllers[game_state.active_player] == "Human"
	var can_act: bool = human_turn and not presenting
	reachable_tiles.clear()
	if can_act:
		reachable_tiles = rules.reachable(game_state.active_player, selected_unit_id)
	attack_tiles.clear()
	if can_act:
		for id: int in rules.attack_targets(game_state.active_player, selected_unit_id):
			if game_state.units.has(id):
				attack_tiles.append(game_state.units[id].hex)
			else:
				attack_tiles.append(game_state.structures[id].hex)
	preview_path.clear()
	attack_preview_label.text = ""
	hover_hex = NONE
	_refresh_tile_materials()
	_update_label()
	turn_label.text = "Player %d | Round %d" % [game_state.active_player, game_state.round_number]
	materials_label.text = "Materials: P1 %d | P2 %d\nActive: Player %d (%s)" % [
		game_state.materials[1], game_state.materials[2], game_state.active_player, player_controllers[game_state.active_player],
	]
	end_turn_button.text = "End Turn - Player %d" % game_state.active_player
	end_turn_button.disabled = game_state.winner_id != 0 or not can_act
	if presenting:
		end_turn_button.text = "Moving..."
	restart_button.visible = game_state.winner_id != 0
	if game_state.winner_id != 0:
		turn_label.text = "Player %d wins" % game_state.winner_id
	_clear_recruit_box()
	if selected_unit_id != -1:
		var unit: GameState.Unit = game_state.units[selected_unit_id]
		var move_status: String = "Moved" if unit.moved else "Ready"
		if unit.attacked:
			move_status = "Spent (attacked)"
		var attack_status: String = "Spent" if unit.attacked else "Ready"
		if game_state.winner_id != 0 or not human_turn:
			move_status = "Disabled"
			attack_status = "Disabled"
		unit_label.text = "Player %d | %s #%d\n(q=%d, r=%d) | HP: %d/%d\nMovement: %d | Damage: %d | Range: %d\nMove: %s | Attack: %s" % [
			unit.owner_id, unit.unit_type, unit.id, unit.hex.x, unit.hex.y, unit.hp, unit.max_hp,
			unit.movement, unit.attack_damage, unit.attack_range, move_status, attack_status,
		]
		if unit.ready_next_turn:
			unit_label.text += "\nReady next turn."
		if unit.owner_id != game_state.active_player:
			unit_label.text += "\nEnemy unit: inspection only."
	elif selected_structure_id != -1:
		var headquarters: GameState.Structure = game_state.structures[selected_structure_id]
		unit_label.text = "Headquarters | Player %d\n(q=%d, r=%d) | HP: %d/%d\nRecruit available: %s" % [
			headquarters.owner_id, headquarters.hex.x, headquarters.hex.y, headquarters.hp, headquarters.max_hp,
			"Yes" if headquarters.recruit_available else "No",
		]
		if headquarters.owner_id == game_state.active_player and can_act and game_state.winner_id == 0:
			for kind: String in UnitTypes.STATS:
				var stats: Dictionary = UnitTypes.STATS[kind]
				var reason: String = rules.recruit_error(game_state.active_player, headquarters.id, kind)
				if reason.is_empty() and rules.recruit_destinations(game_state.active_player, headquarters.id, kind).is_empty():
					reason = "No free adjacent tiles."
				var button := Button.new()
				button.name = "Recruit" + kind
				button.text = "%s: %d materials\nHP %d | Move %d | Range %d | Damage %d" % [
					kind, UnitTypes.COSTS[kind], stats.hp, stats.movement, stats.range, stats.damage,
				]
				button.focus_mode = Control.FOCUS_NONE
				button.disabled = not reason.is_empty()
				button.tooltip_text = reason
				button.pressed.connect(_begin_recruit.bind(kind, headquarters.id))
				recruit_box.add_child(button)
				if not reason.is_empty():
					var explanation: Label = _hud_label(recruit_box)
					explanation.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
					explanation.text = reason
	else:
		unit_label.text = "No unit selected.\nLeft click: inspect / select\nRight click: move / attack\nEsc: clear"

func _update_preview() -> void:
	update_hover_at(get_viewport().get_mouse_position())

func update_hover_at(mouse: Vector2) -> void:
	var destination: Vector2i = NONE
	var over_ui: bool = hud_panel.get_global_rect().has_point(mouse) or coordinate_label.get_global_rect().has_point(mouse)
	if not placement_mode and not over_ui and (not reachable_tiles.is_empty() or not attack_tiles.is_empty()):
		destination = pick_hex(mouse)
	if destination == hover_hex:
		return
	hover_hex = destination
	preview_path.clear()
	attack_preview_label.text = ""
	var target_entity := game_state.entity_at(destination)
	if target_entity != null and target_entity is GameState.Unit:
		var preview: GameRules.Result = rules.preview_attack(game_state.active_player, selected_unit_id, target_entity.id)
		if preview.success:
			var outcome: String = "LETHAL" if preview.killed else "survives"
			attack_preview_label.text = "%s: %d damage\nHP %d -> %d | %s" % [
				target_entity.unit_type, preview.damage, target_entity.hp, preview.target_hp, outcome,
			]
	elif target_entity != null and target_entity is GameState.Structure:
		var preview_s: GameRules.Result = rules.preview_attack(game_state.active_player, selected_unit_id, target_entity.id)
		if preview_s.success:
			attack_preview_label.text = "%s: %d damage\nHP %d -> %d | %s" % [
				target_entity.structure_type, preview_s.damage, target_entity.hp, preview_s.target_hp, "LETHAL" if preview_s.killed else "survives",
			]
	if reachable_tiles.has(destination):
		preview_path = rules.path_to(game_state.active_player, selected_unit_id, destination)
	_refresh_tile_materials()

func _refresh_tile_materials() -> void:
	for hex: Vector2i in tiles:
		var material: StandardMaterial3D = tiles_base_materials.get(hex, normal_material)
		# Placement highlights take precedence
		if placement_mode and recruit_highlights.has(hex):
			material = reachable_material
		elif reachable_tiles.has(hex):
			material = reachable_material
		if preview_path.has(hex):
			material = path_material
		if attack_tiles.has(hex):
			material = attack_material
		if hex == selected:
			material = selected_material
		tiles[hex].material_override = material

func _update_label() -> void:
	var status: String = "none" if selected == NONE else "(q=%d, r=%d)" % [selected.x, selected.y]
	coordinate_label.text = "Selected: %s\nWASD/arrows: pan | Q/E: rotate\nMiddle drag: orbit | Wheel: zoom\nHome: reset" % status

func _find_named_mesh(root: Node, name: String) -> MeshInstance3D:
	for child in root.get_children():
		if child is MeshInstance3D and child.name == name:
			return child
		elif child is Node:
			var res: MeshInstance3D = _find_named_mesh(child, name)
			if res != null:
				return res
	return null

func _find_named_node(root: Node, name: String) -> Node:
	for child in root.get_children():
		if child is Node and child.name == name:
			return child
		elif child is Node:
			var res2: Node = _find_named_node(child, name)
			if res2 != null:
				return res2
	return null

func _owner_color(owner_id: int) -> Color:
	return Color("#75baff") if owner_id == 1 else Color("#f77e75")

func _duplicate_and_tint_material(material: Material, color: Color) -> Material:
	if material == null:
		return _material(color)
	var duplicate: Material = material.duplicate() as Material
	if duplicate is StandardMaterial3D:
		(duplicate as StandardMaterial3D).albedo_color = color
	elif duplicate is ShaderMaterial:
		var shader_material: ShaderMaterial = duplicate as ShaderMaterial
		if shader_material.shader != null:
			for uniform: Dictionary in shader_material.shader.get_shader_uniform_list():
				if uniform.name in ["albedo_color", "team_accent"]:
					shader_material.set_shader_parameter(uniform.name, color)
	return duplicate

func _apply_team_accent(root: Node, owner_id: int) -> void:
	if root is MeshInstance3D:
		var mesh_instance: MeshInstance3D = root as MeshInstance3D
		var color: Color = _owner_color(owner_id)
		if "HX_TeamAccent" in str(mesh_instance.name):
			mesh_instance.material_override = _duplicate_and_tint_material(mesh_instance.material_override, color)
		elif mesh_instance.mesh != null:
			for surface in range(mesh_instance.mesh.get_surface_count()):
				var material: Material = mesh_instance.get_active_material(surface)
				if material != null and "HX_TeamAccent" in material.resource_name:
					mesh_instance.set_surface_override_material(surface, _duplicate_and_tint_material(material, color))
	for child: Node in root.get_children():
		_apply_team_accent(child, owner_id)

func _begin_recruit(kind: String, hq_id: int) -> void:
	if _human_action_blocked():
		return
	var error: String = rules.recruit_error(game_state.active_player, hq_id, kind)
	if not error.is_empty():
		_feedback(error)
		return
	recruit_highlights = rules.recruit_destinations(game_state.active_player, hq_id, kind)
	if recruit_highlights.is_empty():
		_feedback("No free adjacent tiles.")
		return
	placement_mode = true
	recruit_choice = kind
	recruit_hq_id = hq_id
	preview_path.clear()
	attack_preview_label.text = ""
	_feedback("Place %s: left-click green tile. Right-click / Escape cancels." % kind)
	_refresh_tile_materials()

func _queue_ai_turn() -> void:
	if _ai_running or game_state.winner_id != 0 or player_controllers[game_state.active_player] != "AI":
		return
	_ai_running = true
	_start_ai_turn.call_deferred(_ai_token, game_state.active_player)

func _start_ai_turn(token: int, actor: int) -> void:
	var budget: int = maxi(8, game_state.units.size() * 3)
	var attempts: int = 0
	while token == _ai_token and game_state.winner_id == 0 and game_state.active_player == actor and player_controllers[actor] == "AI":
		var action: Dictionary = ai_agent.choose_action(game_state, rules, actor) if attempts < budget else {"type": "end"}
		attempts += 1
		var result: GameRules.Result
		match action.get("type", "end"):
			"attack":
				result = rules.try_attack(actor, action.attacker, action.target)
			"move":
				result = rules.try_move(actor, action.unit, action.dest)
				_present_move(action.unit, result)
			"recruit":
				result = rules.try_recruit(actor, action.hq_id, action.kind, action.dest)
			_:
				result = rules.try_end_turn(actor)
		ai_agent.record_result(action, result.success)
		clear_selection()
		_feedback(result.reason)
		while token == _ai_token and is_presenting():
			await get_tree().process_frame
		if token != _ai_token:
			return
		if game_state.active_player != actor or game_state.winner_id != 0:
			break
		if DisplayServer.get_name() == "headless" or _ai_delay <= 0.0:
			await get_tree().process_frame
		else:
			await get_tree().create_timer(_ai_delay).timeout
	if token == _ai_token:
		_ai_running = false
		_queue_ai_turn()

func handle_recruit_click(screen_position: Vector2) -> void:
	if _human_action_blocked():
		return
	if not placement_mode or player_controllers[game_state.active_player] != "Human":
		return
	var destination: Vector2i = pick_hex(screen_position)
	var result: GameRules.Result = rules.try_recruit(game_state.active_player, recruit_hq_id, recruit_choice, destination)
	if result.success:
		_cancel_recruit(false)
		_refresh_display()
	_feedback(result.reason)

func _cancel_recruit(show_feedback: bool = true) -> void:
	placement_mode = false
	recruit_choice = ""
	recruit_hq_id = -1
	recruit_highlights.clear()
	if show_feedback:
		_feedback("Recruit cancelled.")
	if not tiles.is_empty() and reachable_material != null:
		_refresh_tile_materials()

func is_presenting() -> bool:
	for view: EntityView in unit_views.values():
		if view.moving:
			return true
	return false

func _human_action_blocked() -> bool:
	if player_controllers[game_state.active_player] != "Human":
		return true
	if is_presenting():
		_feedback("Wait for movement to finish.")
		return true
	return false

func _present_move(unit_id: int, result: GameRules.Result) -> void:
	if result.success and animate_movement and unit_views.has(unit_id):
		unit_views[unit_id].play_path(result.path, TOP_Y)

func _focus_selected() -> void:
	# Smoothly move camera focus to currently selected entity or board center
	var dest: Vector3 = Vector3.ZERO
	var found: bool = false
	if selected_unit_id != -1 and unit_views.has(selected_unit_id):
		dest = unit_views[selected_unit_id].global_transform.origin
		found = true
	elif selected_structure_id != -1 and unit_views.has(selected_structure_id):
		dest = unit_views[selected_structure_id].global_transform.origin
		found = true
	if not found:
		# fallback to board center
		var min_world := Grid.to_world(Vector2i(0, 0))
		var max_world := Grid.to_world(Vector2i(Grid.WIDTH - 1, Grid.HEIGHT - 1))
		dest = min_world.lerp(max_world, 0.5)

	cam_target_focus = dest
	# Optionally tighten distance for inspection
	cam_target_distance = clamp(cam_target_distance, cam_min_distance, cam_max_distance)


func _update_camera_transform(delta: float) -> void:
	# Clamp and compute camera world transform from rig parameters
	cam_target_pitch = clamp(cam_target_pitch, cam_min_pitch, cam_max_pitch)
	cam_target_distance = clamp(cam_target_distance, cam_min_distance, cam_max_distance)

	# Convert degrees to radians
	var yaw_rad: float = deg_to_rad(cam_yaw)
	var pitch_rad: float = deg_to_rad(cam_pitch)

	# Spherical offset: yaw rotates around Y, pitch is angle above horizon
	var cos_p := cos(pitch_rad)
	var sin_p := sin(pitch_rad)
	var dx := cam_distance * cos_p * sin(yaw_rad)
	var dz := -cam_distance * cos_p * cos(yaw_rad)
	var dy := cam_distance * sin_p
	var cam_pos := cam_focus + Vector3(dx, dy, dz)

	# Apply position and orientation
	camera.global_transform.origin = cam_pos
	camera.look_at(cam_focus, Vector3.UP)

	# Map orthographic size to distance for intuitive zooming
	camera.size = cam_distance
