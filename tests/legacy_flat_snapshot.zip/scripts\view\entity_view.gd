class_name EntityView
extends MeshInstance3D
## Displays an accepted path. Never reads or writes gameplay state.
signal movement_finished

var visual: UnitVisual
var moving: bool = false
var destination: Vector3
var _waypoints: PackedVector3Array = []
var _next_waypoint: int = 0

func configure(wrapper: Node3D) -> void:
	visual = wrapper as UnitVisual
	if visual != null:
		visual.initialize_animation()
	set_process(false)

func sync_position(logical_position: Vector3) -> void:
	if moving and destination.is_equal_approx(logical_position):
		return
	# Spawn, teleport, or external state replacement cancels obsolete playback.
	cancel_movement()
	position = logical_position
	destination = logical_position

func play_path(path: Array[Vector2i], height: float) -> void:
	cancel_movement()
	if path.size() < 2:
		return
	for hex: Vector2i in path:
		_waypoints.append(HexGrid.to_world(hex) + Vector3(0, height, 0))
	position = _waypoints[0]
	destination = _waypoints[-1]
	_next_waypoint = 1
	moving = true
	_face(_waypoints[1] - position)
	if visual != null:
		visual.set_moving(true)
	set_process(true)

func _process(delta: float) -> void:
	advance_movement(delta)

func advance_movement(delta: float) -> void:
	# Consume any overshoot at each corner: never cut across blocked hexes and
	# remain consistent across frame rates, including a long/stalled frame.
	var remaining: float = maxf(delta, 0.0) * (maxf(0.1, visual.move_speed) if visual != null else 4.0)
	while moving and remaining > 0.0:
		var target: Vector3 = _waypoints[_next_waypoint]
		var distance: float = position.distance_to(target)
		_face(target - position)
		if remaining < distance:
			position = position.move_toward(target, remaining)
			return
		position = target
		remaining -= distance
		_next_waypoint += 1
		if _next_waypoint == _waypoints.size():
			cancel_movement()
			movement_finished.emit()

func cancel_movement() -> void:
	moving = false
	_waypoints.clear()
	set_process(false)
	if visual != null:
		visual.set_moving(false)

func _face(direction: Vector3) -> void:
	if visual != null and direction.length_squared() > 0.000001:
		# Rotate the wrapper; preserve imported bones, tracks and ModelRoot scale.
		visual.rotation.y = atan2(-direction.x, -direction.z)
